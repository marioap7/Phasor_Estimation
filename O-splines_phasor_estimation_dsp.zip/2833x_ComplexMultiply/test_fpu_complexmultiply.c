
#include "DSP2833x_Device.h"
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File
#include "fpu_vector.h"		    // Main include file
#include <math.h>
#include "fpu_math.h"
#include <complex.h>

#define SIZE        320

// Global variables for complex multiply test
complex_float p, pp, ppp, F1, aep1 , imag, phi, temp1, temp2, temp3, add_ppR1;



complex_float signal[SIZE] = {
    #include "signal.h"
};
complex_float hm[SIZE] = {
    #include "hm1.h"
};

complex_float hpm[SIZE] = {
    #include "hpm.h"
};
/*
complex_float hppm[SIZE] = {
    #include "hppm.h"
};*/


// external function prototypes
extern void InitSysCtrl(void);
extern void InitPieVectTable(void);
extern void InitPieCtrl(void);
extern void InitCpuTimers(void);
extern void ConfigCpuTimer(struct CPUTIMER_VARS *, float, float);

// Prototype statements for functions found within this file.
void Gpio_Select(void);
void Init_Adc(void);

// Function Prototype statements of CPU ISR interruptions
//
__interrupt void cpu_timer0_isr(void);
__interrupt void cpu_timer1_isr(void);
__interrupt void cpu_timer2_isr(void);

interrupt void cpu_timer0_isr(void);

volatile float TBPRD_reg;
volatile unsigned char ISR_timer0_flag;

volatile int i, j;
volatile float Buffer_input_signal[SIZE+10], A[SIZE], PH[SIZE], input_signal, input_signal_gain, input_signal_offset, a, ae, ph, add_pR, add_pI, add_ppR, add_ppI, add_pppR, add_pppI, aepR, freq, phepR, FR[SIZE];
void main(void)
{
//--- CPU Initialization
/*    InitSysCtrl();                      // Initialize the CPU
    DINT;
    InitPieCtrl();                      // Initialize and enable the PIE
    IER = 0x0000;
    IFR = 0x0000;
    InitPieVectTable();
    EINT;                               // Enable Global interrupt INTM
    ERTM;  */  // Enable Global realtime interrupt DBGM

        InitSysCtrl();  // Basic Core Init from DSP2802x_SysCtrl.c


        EALLOW;
        //SysCtrlRegs.WDCR= 0x00AF; // Re-enable the watchdog
        EDIS;           // 0x00AF  to NOT disable the Watchdog, Prescaler = 64

        DINT;               // Disable all interrupts

        Gpio_Select();      // GPIO34 as output (LED) & EPWM1A
      //Setup_ePWM();       // init of ePWM1A

        InitPieCtrl();      // basic setup of PIE table; from DSP2833x_PieCtrl.c
        InitPieVectTable(); // default ISR's in PIE

        //
        EALLOW;  // TEALLOW and EDIS are two macros to enable and disable the access to a group of protected registers; the PIE is part of this area.his is needed to write to EALLOW protected registers
        PieVectTable.TINT0 = &cpu_timer0_isr;//CPU-Timer0 Interrupt Service directly inside the PIE-memory
        PieVectTable.XINT13 = &cpu_timer1_isr;
        PieVectTable.TINT2 = &cpu_timer2_isr;

        EDIS;    // This is needed to disable write to EALLOW protected registers
        InitCpuTimers();   // For this example, only initialize the Cpu Timers
        //
        // Configure CPU-Timer 0, 1, and 2 to interrupt every second:
        // 150MHz CPU Freq, 1 second Period (in uSeconds)
        //
        ConfigCpuTimer(&CpuTimer0, 150, 520);//Frecuencia de la interrupcion 1 de 1MHz. 1uS, si es necesario se puede reducir hasta 0.2uS
       // ConfigCpuTimer(&CpuTimer1, 150, 100);//si se cambia se debe cambiar la frecuencia configurada en el PLL, Frecuencia de la interrupcion 20kHz. 50us//solar library indica que la frecuencia minima del PLL es de 20kHz
       // ConfigCpuTimer(&CpuTimer2, 150, 50);//Frecuencia de la interrupcion 10kHz. 100uS
        //
        // To ensure precise timing, use write-only instructions to write to the
        // entire register. Therefore, if any of the configuration bits are changed
        // in ConfigCpuTimer and InitCpuTimers (in DSP2833x_CpuTimers.h), the
        // below settings must also be updated.
        //
         CpuTimer0Regs.TCR.all = 0x4000; //write-only instruction to set TSS bit = 0
         CpuTimer1Regs.TCR.all = 0x4000; //write-only instruction to set TSS bit = 0
         CpuTimer2Regs.TCR.all = 0x4000; //write-only instruction to set TSS bit = 0

        // Step 5. User specific code, enable interrupts

        // Enable CPU int1 which is connected to CPU-Timer 0, CPU int13
        // which is connected to CPU-Timer 1, and CPU int 14, which is connected
        // to CPU-Timer 2:
        //
        IER |= M_INT1;
        IER |= M_INT13;
        IER |= M_INT14;


        EDIS;

        Init_Adc();  //  init the ADC

        PieCtrlRegs.PIEIER1.bit.INTx7 = 1;// Enable TINT0 in the PIE: Group 1 interrupt 7

        IER |=1;

        EINT;
        ERTM;


        //IER = 0x0000;
        IFR = 0x0000;
        input_signal_gain=0.0834999979;
        input_signal_offset=2030.0;

        i=0;
        add_pR=0;
        add_pI=0;
        j=0;
        F1.dat[0]=60;
        F1.dat[1]=0;
        imag.dat[0]=0;
        imag.dat[1]=1;


//--- Main Loop
	while(1)							// Dummy loop.  Wait for an interrupt.
	{
		asm(" NOP");
        EALLOW;
        if (ISR_timer0_flag==1){
            GpioDataRegs.GPBDAT.bit.GPIO34=1;

            Buffer_input_signal[SIZE-1] = input_signal_gain*(AdcMirror.ADCRESULT0- input_signal_offset);

            for(i = 1; i<SIZE; i++){
                Buffer_input_signal[i-1]=Buffer_input_signal[i];
                signal[i].dat[0]=Buffer_input_signal[i];

                p = mpy_SP_CSxCS(hm[i], signal[i]); // complex multiply
                pp = mpy_SP_CSxCS(hpm[i], signal[i]); // complex multiply
                //ppp = mpy_SP_CSxCS(hppm[i], signal[i]); // complex multiply

                add_pR=add_pR+p.dat[0];
                add_pI=add_pI+p.dat[1];

                add_ppR=add_ppR+pp.dat[0];
                add_ppI=add_ppI+pp.dat[1];

               // add_pppR=add_pppR+ppp.dat[0];
                //add_pppI=add_pppI+ppp.dat[1];
            }
            a = sqrt(add_pR*add_pR+add_pI*add_pI);
            ae=a*2;
            ph=atan(add_pI/add_pR);
            PH[j]=ph;
            A[j]=ae;


            phi.dat[0]=-ph;
            phi.dat[1]=0;
            add_ppR1.dat[0]=add_ppR;
            add_ppR1.dat[1]=add_ppI;



            temp1.dat[0]=cos(ph);
            temp1.dat[1]=-sin(ph);


            temp2=mpy_SP_CSxCS(add_ppR1, F1);
            aep1=mpy_SP_CSxCS(temp2, temp1);
            aepR=2*aep1.dat[0];
            phepR=(2*aep1.dat[1])/ae;
            freq=60-phepR/(2* 3,1415926535897932);
            FR[j]=freq;



            add_pR=0;
            add_pI=0;
            add_ppR=0;
            add_ppI=0;
            j=j+1;

           if(j==SIZE)
               {
                   j=0;
               }

            ISR_timer0_flag=0;
            GpioDataRegs.GPBDAT.bit.GPIO34=0;
        }//end if
        EDIS;
	}

} // end of main()




void Gpio_Select(void)
{
    EALLOW;
    GpioCtrlRegs.GPAMUX1.all = 0;       // GPIO15 ... GPIO0 = General Puropse I/O
    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 0; // (1) ePWM1A active (0) inactive
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 0; // ePWM1B active

    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 0; // ePWM2A active
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 0; // ePWM2B active
    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 0; // ePWM3A active
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 0; // ePWM3B active


    GpioCtrlRegs.GPAMUX2.all = 0;       // GPIO31 ... GPIO16 = General Purpose I/O
    GpioCtrlRegs.GPBMUX1.all = 0;       // GPIO38 ... GPIO32 = General Purpose I/O
    GpioCtrlRegs.GPADIR.all = 0;
    GpioCtrlRegs.GPBDIR.all = 0;        // GPIO38 ... GPIO32 as inputs
    GpioCtrlRegs.GPBDIR.bit.GPIO34 = 1; // GPIO34 as output (LED LD2 at 28027stick)

    EDIS;
}


// cpu_timer0_isr -
//
__interrupt void cpu_timer0_isr(void){    // todo lo que se ejecute aca deberia tardar menos de 0.5us

    EALLOW;
    ISR_timer0_flag=1;
    CpuTimer0.InterruptCount++;
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;// Acknowledge this interrupt to receive more interrupts from group 1

    EDIS;
}

//
// cpu_timer1_isr - -
//
__interrupt void cpu_timer1_isr(void) {

       EALLOW;
        CpuTimer1.InterruptCount++;
        PieCtrlRegs.PIEACK.all = PIEACK_GROUP2;
        EDIS;
}

//
// cpu_timer2_isr
//
__interrupt void cpu_timer2_isr(void){

    EALLOW;
    CpuTimer2.InterruptCount++;// The CPU acknowledges the interrupt.
    EDIS;
}

// Configutation of ADC channels
void Init_Adc(void)
{
    extern void DSP28x_usDelay(Uint32 Count);

    /***************************************************************************************************
     * XCLKIN   SYSCLKOUT   HISPCLK   ADCTRL3[4-1]   ADCTRL1[7]   ADCCLK   ADCTRL1[11-8]   SH Width
     *                      HSPCP=3   ADCLKPS=0        CPS=0                ACQ_PS=0     12.5 MSPS sustained
     * 30MHz     150MHz     25MHz      25MHz           25MHz      25MHz       12.5 MHz       40 ns
     **************************************************************************************************/

    EALLOW;//This bit, when set, enables access to emulation and other protected registers. Set this bit by using the EALLOW instruction and clear this bit by using the EDIS instruction.
    SysCtrlRegs.HISPCP.all = 3;    //esta instruccion equivale a ADC_MODCLK=0x3;  HSPCLK = SYSCLKOUT/ADC_MODCLK;ADC_MODCLK=0x3
    EDIS;
    // Default - 150 MHz SYSCLKOUT // configuracon del reloj del ADC
    // HSPCLK = SYSCLKOUT/2*ADC_MODCLK2 = 150/(2*3)   = 25.0 MHz ; i.e. (SysCtrlRegs.HISPCP.all = 3;)
    // ADC module clock = HSPCLK/2*ADC_CKPS   = 25.0MHz/(1*2) = 12.5MHz
    //
    //                          *IMPORTANT*
    // The ADC_cal function, which  copies the ADC calibration values from
    // TI reserved OTP into the ADCREFSEL and ADCOFFTRIM registers, occurs
    // automatically in the Boot ROM. If the boot ROM code is bypassed during
    // the debug process, the following function MUST be called for the ADC to
    // function according to specification. The clocks to the ADC MUST be
    // enabled before calling this function. See the device data manual and/or
    // the ADC Reference Manual for more information.
    //
    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1;
    SysCtrlRegs.PCLKCR0.bit.ADCENCLK=1; //Set the ADC clock enable
    ADC_cal();
    EDIS;

    //
    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks, followed by powering up the bandgap, reference circuitry, and
    // ADC core. Before the first conversion is performed a 5ms delay must be
    // observed after power up to give all analog circuits time to power up
    // and settle
    //
    // Please note that for the delay function below to operate correctly the
    // CPU_RATE define statement in the DSP2833x_Examples.h file must
    // contain the correct CPU clock period in nanoseconds.
    //
    AdcRegs.ADCTRL3.all = 0x00E0;  // Power up bandgap/reference/ADC circuits
    DELAY_US(5000L);         // Delay before converting ADC channels//Allow a delay of 5 ms for F280xx (10 ms for F281x) after ADC power up so that the external
    //capacitors on the REFP and REFN pins are charged properly . ADC counts during this
    //period (delay) will not be accurate.

    // Specific ADC setup
    //1. Setting the ADC Clock Frequency and Sampling Rate
    AdcRegs.ADCTRL1.bit.CPS=0; //ADC module clock =25.0MHz; CPS=0 => ADCCLK = Fclk/1
    AdcRegs.ADCTRL1.bit.ACQ_PS = 0;//This bit field controls the width of SOC pulse, which, in turn, determines for what time duration the sampling switch is closed.ACQ_PS = 0 Fclk/1; ACQ_PS = 1 Fclk/2; S/H width in ADC module periods = 1 ADC clocks 12.5 MHz 12.5 MSPS sustained 40 ns; ADCCLKPS = 5 cause 12,5Mhz/10.
    AdcRegs.ADCTRL3.bit.ADCCLKPS = 0; // ADCCLKPS = 0; ADC module clock = HSPCLK/2*ADCCLKPS   = 25.0MHz/(1*2) = 12.5MHz
    AdcRegs.ADCMAXCONV.all = 8;       // Setup 2 conv's on SEQ1
    AdcRegs.ADCCHSELSEQ1.bit.CONV00 = 0; //Set ADCCHSELSEQ1 to ADCCHSELSEQ4 registers to assign the ADC input channel (ADCINAx andADCINBx) for each conversion (CONVnn).
    AdcRegs.ADCCHSELSEQ1.bit.CONV01 = 1; //Set ADCCHSELSEQ1 to ADCCHSELSEQ4 registers to assign the ADC input channel (ADCINAx andADCINBx) for each conversion (CONVnn).
    AdcRegs.ADCCHSELSEQ1.bit.CONV02 = 2; //Set ADCCHSELSEQ1 to ADCCHSELSEQ4 registers to assign the ADC input channel (ADCINAx andADCINBx) for each conversion (CONVnn).
    AdcRegs.ADCCHSELSEQ1.bit.CONV03 = 3; //Set ADCCHSELSEQ1 to ADCCHSELSEQ4 registers to assign the ADC input channel (ADCINAx andADCINBx) for each conversion (CONVnn).
    AdcRegs.ADCCHSELSEQ2.bit.CONV04 = 4;
    AdcRegs.ADCCHSELSEQ2.bit.CONV05 = 5;
    AdcRegs.ADCCHSELSEQ2.bit.CONV06 = 6;
    AdcRegs.ADCCHSELSEQ2.bit.CONV07 = 7;
    AdcRegs.ADCTRL1.bit.CONT_RUN = 1;       // Setup continuous run
    AdcRegs.ADCTRL3.bit.SMODE_SEL=0; // 0 for sequential mode and to 1 for simultaneous mode.
    AdcRegs.ADCTRL1.bit.SEQ_CASC = 1;        // 1  Cascaded mode
    AdcRegs.ADCTRL2.all = 0x2000; // Start SEQ1 Reset sequencer1 Writing a 1 to this bit resets SEQ1 or the cascaded sequencer immediately to an initial "pretriggered" state, i.e., waiting for a trigger at CONV00. A currently active conversion sequence will be aborted.
}




    //===========================================================================
// End of SourceCode.
//===========================================================================


//===========================================================================
// End of File
//===========================================================================

